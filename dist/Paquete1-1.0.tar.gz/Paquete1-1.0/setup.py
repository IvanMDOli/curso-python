from setuptools import setup

setup(

    name="Paquete1",
    version="1.0",
    description="Primer paquete distribuible.",
    author="Pre-Entrega 2 - CODER Python",
    author_email="ivanmdeoli@hotmail.com",

    packages=["Paquete1"]
)